package com.felix.hello.service;

import com.felix.hello.dto.Purchase;
import com.felix.hello.dto.PurchaseResponse;

public interface CheckoutService {
    PurchaseResponse placeOrder(Purchase purchase);
}


