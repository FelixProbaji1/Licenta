package com.felix.hello.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.felix.hello.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
    
    
}
