package com.felix.hello.dto;

import java.util.Set;

import com.felix.hello.entity.Address;
import com.felix.hello.entity.Customer;
import com.felix.hello.entity.Order;
import com.felix.hello.entity.OrderItem;

import lombok.Data;

@Data
public class Purchase {

    private Customer customer;
    private Address shippingAddress;
    private Order order;
    private Set<OrderItem> orderItems;
    
}
